$(".upload-btn").click(function () {
    $(".upload-input").trigger('click');
});