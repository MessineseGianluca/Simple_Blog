<?php
  class Config {
      public $servername = 'localhost';
      public $username = 'username';
      public $password = 'password';
      public $dbname = 'blogdb';
  } 

